<template>
  <div>
    <h1>{{ msg }}</h1>
  </div>
</template>

<script>
export default {
  name: 'page2',
  data () {
    return {
      msg: 'page2页面'
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
div h1 
{
  font-size: 120px;
}

</style>
