<template>
  <div>
    <h1>{{ msg }}</h1>
    <ul>
        <h2><router-link to='/page1'>简单的路由连接1</router-link></h2>
        <h2><router-link to='/page2'>简单的路由连接2</router-link></h2>
        <h2><router-link to='/page3'>简单的路由连接3</router-link></h2>
    </ul>
    <div>
      <router-view/>
    </div>
    <h4><router-link to='/'>回到首页</router-link></h4>
  </div>
</template>

<script>
export default {
  name: 'list',
  data () {
    return {
      msg: '简单的路由列表'
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1 
{
  font-size: 120px;
}

</style>
