<template>
  <div>
    <h1>{{ msg }}</h1>
    <h2><router-link to='/list'>简单的路由列表</router-link></h2>
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  data () {
    return {
      msg: 'HelloWorld.vue'
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1 
{
  font-size: 120px;
}
</style>
